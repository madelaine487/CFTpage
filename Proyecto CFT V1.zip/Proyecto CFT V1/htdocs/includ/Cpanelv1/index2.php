<!-- LOGIN Y REGISTRO  -->
<!-- V.01 -->
<!-- CREADOR -->
<!-- JHONATAN CARDONA --><!-- PRORAMADOR SOFTWARE --><!-- 2018 --><!-- copyright 2018- 2038 -->

<html>
    
    <head>
        
        <title>user</title>
        
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>  
        
        
        
    </head>
    
    <body>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
      <center>
          
         <p>
             
            <h1>pagina principal para el usuario</h1> 
         </p> 
         
         <br>
         <br>
         <br>
         <p>
             
             
             <h1>
                 
               Contenido  
                 
        </h1>
            
            <button class="btn btn "><a href="desconectar.php">Cerrar</a></button>
             
             
         </p>
          
          
          
          
          
      </center>  
        
        
        
        
        
        
        
    </body>
    
    
    
</html>