<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="author" content="Javier Ponferrada López">
  <link rel="stylesheet" href="css/style.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.2.1.min.js" charset="utf-8"></script>
  <script src="js/script.js" charset="utf-8"></script>
  <link rel="stylesheet" href="menu.css">
  <title>Menu</title>
</head>
<body>
  <div class="Nav-social">
    <center>Incluir redes Sociales</center>
  </div>
    <nav class="menu">
      <div class="content_icon_open_nav">
        <div class="icon_open_nav"onclick="selectButtonMenu();">
          <div class="line_button_open_nav" id="line_1"></div>
          <div class="line_button_open_nav" id="line_2"></div>
          <div class="line_button_open_nav" id="line_3"></div>
        </div>
      </div>
      <ul>
        <li><a href="#">Inicio</a></li>
        <li><a href="#">Nosotros</a></li>
        <li><a href="#">Sedes</a></li>
        <li><a href="/includ/Cpanelv1/index.php">Ingreso</a></li>
      </ul>
    </nav>
    <div class="bloque_opacity" onclick="selectButtonMenu();">

    </div>

</body>
<script src="menu-js.js"></script>
</html>
