<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>CFT PUCV</title>
	<link rel="stylesheet" href="includ/menu-primary/menu.css">
	<link rel="stylesheet" href="includ/footerv1/footer.css">
</head>
<body>
	<?php include "includ/menu-primary/menu.php" ?>

	<div>

	</div>
</body>
<script src="includ/menu-primary/menu-js.js"></script>
</html>